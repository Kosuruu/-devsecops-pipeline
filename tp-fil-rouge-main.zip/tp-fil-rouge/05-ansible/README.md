# 05 - Playbook Ansible (durcissement + application)

Livrable 5/8 du TP fil rouge Guardia. Ce repertoire contient le playbook Ansible qui durcit la
VM cible de l'etudiant (Debian 13, poste local VMware Workstation Player) et y deploie une
application Flask minimaliste servie par gunicorn derriere nginx.

Ce livrable est de la documentation et du code destines a etre executes par l'utilisateur
(l'etudiant ou l'instructeur) lui-meme. Aucune commande listee ici n'est executee par
l'assistant qui a genere ces fichiers.

## Prerequis

Sur le poste de controle (poste instructeur ou runner CI, cf. livrable 6) :

- Ansible core >= 2.16
- ansible-lint >= 24.x (utilise par le job "lint" du workflow Gitea Actions, livrable 7)
- Collection `community.general` (fournit le module `ufw`) :
  ```
  ansible-galaxy collection install community.general
  ```
- Python >= 3.10 pour l'interpreteur local d'Ansible
- Acces SSH a la VM cible avec la cle privee de l'etudiant (cf. `inventory/hosts.ini.example`)

Sur la VM cible : Debian 13 minimal, acces reseau sortant (apt, PyPI) autorise par la regle
pare-feu OPNsense du VLAN 12 (cf. `02-reseau-isolation/README.md`).

## Mise en place avant premiere execution

1. Copier les fichiers d'exemple et les completer :
   ```
   cp inventory/hosts.ini.example inventory/hosts.ini
   cp group_vars/all.yml.example group_vars/all.yml
   ```
2. Editer `inventory/hosts.ini` avec l'IP reelle de la VM cible, l'utilisateur admin Ansible et
   le chemin vers la cle privee SSH de l'etudiant.
3. Adapter `group_vars/all.yml` si besoin (ports, noms de service). Les valeurs par defaut
   correspondent a la spec du TP et n'ont normalement pas besoin d'etre modifiees.

Ni `hosts.ini` ni `all.yml` ne doivent etre commites s'ils contiennent des chemins ou IP propres
a une machine d'etudiant (les fichiers `.example` versionnes ne contiennent que des placeholders).

## Lancer le playbook (a executer manuellement)

Depuis le repertoire `05-ansible` :

```
ansible-playbook -i inventory/hosts.ini site.yml
```

Verification de syntaxe avant execution reelle (utilisee par le job "test" du workflow Gitea
Actions, livrable 7) :

```
ansible-playbook -i inventory/hosts.ini site.yml --syntax-check
ansible-playbook -i inventory/hosts.ini site.yml --check
```

Lint (utilise par le job "lint" du workflow Gitea Actions) :

```
ansible-lint site.yml
```

## Pourquoi Flask + nginx plutot qu'un nginx statique seul

Le TP vise des fondamentaux ISR (reseau/systeme) **et** dev. Un simple nginx servant une page
statique valide le reverse proxy et le pare-feu, mais n'apporte aucune valeur pedagogique cote
developpement. Le choix Flask + gunicorn + nginx permet de couvrir dans un seul livrable :

- un vrai processus applicatif (gunicorn) gere par systemd, avec son propre utilisateur de
  service, illustrant le principe de moindre privilege (l'application ne tourne jamais sous
  l'utilisateur admin/ansible) ;
- un environnement virtuel Python isole (`python3-venv`), pratique de base en dev Python ;
- une route `/healthz` qui sert de point de verification technique reutilise a la fois par la
  tache Ansible finale (module `uri`) et par le job "deploy" du workflow Gitea Actions
  (livrable 7), ce qui relie concretement Git/CI/CD/Ansible/DevSecOps dans le meme TP fil rouge ;
- un cas reel de reverse proxy nginx vers une application backend, plus representatif d'une
  architecture web moderne qu'un simple site statique.

## Securite

- **sudo large sur l'utilisateur admin (`ansible_user`)** : ce TP accepte un sudo NOPASSWD large
  sur le compte admin/SSH utilise par Ansible, pour ne pas complexifier la configuration d'un
  lab de 4 jours avec 40 etudiants en autonomie. C'est un compromis assume et documente, pas une
  pratique recommandee : en environnement de production, le sudo doit etre restreint aux
  commandes strictement necessaires (regles `sudoers` ciblees, pas de `NOPASSWD ALL`).
- **`host_key_checking = False`** (dans `ansible.cfg`) : desactive uniquement parce que la VM
  cible de chaque etudiant est frequemment recreee (nouvelle installation, restauration cloud-init,
  snapshot) et changerait sinon de cle d'hote SSH a chaque fois, bloquant Ansible avec une alerte
  de securite a chaque execution. Ce reglage n'est pas reproductible en production : il doit y
  rester active, avec une distribution fiable des cles d'hote connues.
- L'application applicative tourne sous un compte de service dedie (`tpapp`), systeme, sans
  shell de connexion, et n'ecoute qu'en local (`127.0.0.1:8000`) : seul nginx est expose sur le
  port 80, ce qui limite la surface d'attaque directe sur gunicorn.
- Le pare-feu ufw applique une politique "deny incoming" par defaut et n'autorise explicitement
  que les ports definis dans `group_vars/all.yml` (22/tcp et 80/tcp par defaut).
- sshd est durci (`PermitRootLogin no`, `PasswordAuthentication no`) : la connexion root et
  l'authentification par mot de passe sont desactivees, seule l'authentification par cle SSH
  reste possible.
