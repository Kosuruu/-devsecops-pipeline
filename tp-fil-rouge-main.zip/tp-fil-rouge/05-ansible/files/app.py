#!/usr/bin/env python3
"""Prerequis : Python >= 3.10, Flask >= 3.0, gunicorn >= 22.0 (cf. requirements.txt).

Application Flask minimaliste utilisee comme livrable applicatif du TP fil rouge Guardia.
Deployee par Ansible (05-ansible/site.yml) dans un environnement virtuel, executee par
gunicorn sous systemd avec l'utilisateur de service applicatif (tpapp), ecoute en local
uniquement (127.0.0.1:8000) et exposee via nginx en reverse proxy sur le port 80.

Routes :
- GET /        : reponse texte simple avec le hostname et l'horodatage courant.
- GET /healthz : reponse JSON de sante, utilisee par la verification finale du playbook
                 (module uri) et par le job "deploy" du workflow Gitea Actions (livrable 7).
"""

import socket
from datetime import datetime, timezone

from flask import Flask, jsonify

app = Flask(__name__)


@app.route("/")
def index():
    hostname = socket.gethostname()
    horodatage = datetime.now(timezone.utc).isoformat()

    return f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guardia Cyber Lab</title>
    <style>
        body {{
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0b1020;
            color: #e8eaff;
            font-family: Arial, sans-serif;
        }}
        .card {{
            width: min(700px, 90%);
            padding: 45px;
            border: 1px solid #303b70;
            border-radius: 20px;
            background: #111936;
            box-shadow: 0 0 40px rgba(80, 100, 255, 0.15);
        }}
        h1 {{
            margin-top: 0;
            font-size: 42px;
        }}
        .accent {{ color: #8b7cff; }}
        .status {{
            display: inline-block;
            margin: 20px 0;
            padding: 10px 16px;
            border-radius: 999px;
            background: #172c24;
            color: #72e6a3;
        }}
        .info {{
            line-height: 1.8;
            color: #b8c0df;
        }}
        code {{ color: #9da8ff; }}
    </style>
</head>
<body>
    <main class="card">
        <h1>🛡️ Guardia <span class="accent">Cyber Lab</span></h1>
        <div class="status">● Application opérationnelle</div>

        <p class="info">
            Bienvenue sur mon TP fil rouge de cybersécurité.
        </p>

        <p class="info">
            <strong>Hôte :</strong> {hostname}<br>
            <strong>Déployé avec :</strong> Ansible<br>
            <strong>Reverse proxy :</strong> Nginx<br>
            <strong>Application :</strong> Flask + Gunicorn<br>
            <strong>Déploiement :</strong> CI/CD Gitea Actions
        </p>

        <p class="info">
            <strong>Dernière vérification :</strong><br>
            <code>{horodatage}</code>
        </p>
    </main>
</body>
</html>
"""


@app.route("/healthz")
def healthz():
    return jsonify(status="ok", eleve="Rubens Bonnin")


if __name__ == "__main__":
    # Point d'entree de developpement uniquement (non utilise en production : gunicorn
    # est le serveur WSGI reel, lance via le service systemd tp-app).
    app.run(host="127.0.0.1", port=8000)
