# Livrable 7 : Workflow Gitea Actions (lint / test / deploy)

Prerequis : un depot Gitea "tp-fil-rouge" existant dans l'organisation de l'etudiant (livrable 3),
contenant deja le repertoire `05-ansible/` du livrable 5, et un act_runner du livrable 6 enregistre
et demarre (le job ne pourra jamais demarrer sinon : aucun runner ne portera le label attendu).

## 1. Ou placer ce fichier

`deploy.yml` n'est PAS destine a rester dans `07-gitea-workflow/` : c'est un modele a copier tel
quel, par chaque etudiant, dans son propre depot `tp-fil-rouge`, au chemin exact :

```
.gitea/workflows/deploy.yml
```

Depuis la racine du depot etudiant (a executer soi-meme, pas par l'assistant) :

```bash
mkdir -p .gitea/workflows
cp /chemin/vers/07-gitea-workflow/deploy.yml .gitea/workflows/deploy.yml
git add .gitea/workflows/deploy.yml
git commit -m "Ajout du workflow de deploiement CI/CD"
git push origin main
```

Gitea detecte automatiquement tout fichier `.gitea/workflows/*.yml` et le propose comme workflow
Actions des le prochain push, a condition que Gitea Actions soit active sur l'instance (deja fait
sur gitea-guardia.novidemo.fr) et qu'un runner compatible soit enregistre et demarre.

## 2. Verifier le label du runner (livrable 6)

Le workflow utilise `runs-on: tp-runner` dans ses 3 jobs. Ce label doit correspondre EXACTEMENT
a celui declare dans `runner.labels` du `config.yaml` de l'act_runner local (livrable 6). Si le
label configure differe, modifier les 3 occurrences de `runs-on:` dans `deploy.yml` en consequence
avant de commiter.

## 3. Declarer les secrets et variables (interface web Gitea uniquement)

Aucune de ces valeurs ne doit jamais figurer en clair dans `deploy.yml` ni dans aucun fichier
commite. Tout se declare depuis l'interface web du depot, jamais via l'API ni en ligne de commande :

Dans le depot etudiant sur `https://gitea-guardia.novidemo.fr` :
`Settings` (Parametres du depot) -> `Actions` -> `Secrets` et `Actions` -> `Variables`.

### Secret masque (onglet Secrets)

| Nom | Valeur | Remarque |
|---|---|---|
| `DEPLOY_SSH_KEY` | Cle privee SSH complete (bloc `-----BEGIN ... PRIVATE KEY-----`) | Cle dediee au deploiement, sans passphrase, dont la cle publique correspondante est deja presente dans `~/.ssh/authorized_keys` du compte `ansible` sur la VM cible (livrable 4). Ne jamais reutiliser une cle SSH personnelle. |

Une fois enregistree, la valeur d'un secret n'est plus jamais affichee dans l'interface : seul le
nom reste visible. Le job y accede via `${{ secrets.DEPLOY_SSH_KEY }}` et Gitea masque
automatiquement toute occurrence de cette valeur dans les logs d'execution.

### Variables non sensibles (onglet Variables)

| Nom | Valeur exemple | Remarque |
|---|---|---|
| `TARGET_HOST` | `192.168.x.x` | IP locale de la VM cible (livrable 4), propre a la machine de l'etudiant. Faible sensibilite : reste une IP privee locale, mais est declaree en variable (pas en dur dans le fichier) pour que le meme workflow fonctionne pour les 40 etudiants sans modification. |
| `TARGET_USER` | `ansible` | Compte SSH utilise par Ansible sur la cible (livrable 4). |

Ces deux valeurs sont accessibles via `${{ vars.TARGET_HOST }}` et `${{ vars.TARGET_USER }}` et
apparaissent en clair dans les logs (normal, ce ne sont pas des secrets).

## 4. Rappel de securite

- Ne jamais coller `DEPLOY_SSH_KEY`, un mot de passe ou un token directement dans `deploy.yml` :
  seule la reference `${{ secrets.DEPLOY_SSH_KEY }}` doit apparaitre dans le fichier commite.
- Ne jamais ajouter la cle privee, ni un fichier `inventory/hosts.ini` genere (contenant l'IP et le
  chemin de cle), au depot Git : le job `deploy.yml` regenere cet inventaire a chaque execution a
  partir des variables du depot, il ne doit jamais etre commite tel quel.
- Si une cle privee a ete collee par erreur dans un commit (meme ensuite supprime), la considerer
  comme compromise : en generer une nouvelle et retirer l'ancienne des `authorized_keys` de la cible.

## 5. Pourquoi l'ordre lint -> test -> deploy

- `lint` : verifie la qualite/forme du playbook (ansible-lint) avant toute autre chose, rapide et
  sans acces reseau a la cible.
- `test` : garde-fou PRE-VOL, `--syntax-check` puis `--check --diff` (dry-run) contre la cible reelle
  via SSH, mais sans modifier quoi que ce soit sur celle-ci.
- `deploy` : execution reelle du playbook, PUIS verification finale par `curl` sur `/healthz`. Cette
  verification arrive en dernier expres : c'est un dernier filet de securite qui controle que
  l'application repond reellement une fois deployee, meme si l'execution d'Ansible elle-meme s'est
  terminee sans erreur. Le job (et donc le workflow) echoue si `/healthz` ne renvoie pas un code 2xx.
