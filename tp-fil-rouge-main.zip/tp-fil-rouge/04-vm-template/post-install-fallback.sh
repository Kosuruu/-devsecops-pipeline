#!/usr/bin/env bash
# =============================================================================
# post-install-fallback.sh
#
# Script de secours : a executer MANUELLEMENT, EN LOCAL SUR LA VM CIBLE
# (dans un terminal ouvert sur la VM, apres connexion en local ou en SSH
# avec le compte cree pendant l'installation Debian), apres une installation
# Debian 13 (Trixie) standard depuis l'ISO officielle, SI le chemin
# cloud-init (voir 04-vm-template/README.md, "Chemin A") ne fonctionne pas
# (VMware Workstation Player qui ignore le second lecteur CD-ROM,
# cloud-init absent ou en erreur, etc.).
#
# Reproduit manuellement ce que cloud-init aurait fait :
#   - installation des paquets necessaires (sudo, openssh-server,
#     open-vm-tools)
#   - creation du compte admin 'ansible' (sudo NOPASSWD, cle SSH uniquement)
#   - desactivation de l'authentification par mot de passe SSH + du login
#     root SSH
#   - definition du hostname
#
# Prerequis :
#   - Debian 13 minimal fraichement installee, connexion reseau active
#   - Execution en tant que root (via "sudo bash post-install-fallback.sh ..."
#     ou apres "su -")
#   - Avoir DEJA genere SA PROPRE paire de cles SSH sur SA machine (jamais
#     de cle partagee entre etudiants, jamais fournie par l'instructeur) :
#         ssh-keygen -t ed25519 -C "etuNN@guardia-tp"
#     et avoir rendu la CLE PUBLIQUE disponible sur cette VM (fichier .pub
#     copie via cle USB, presse-papiers partage VMware Tools, ou saisie
#     manuelle dans un fichier avec un editeur type nano).
#
# Usage :
#   sudo ./post-install-fallback.sh /chemin/vers/cle_publique.pub [hostname]
#
#   Exemple :
#   sudo ./post-install-fallback.sh /root/id_ed25519_etu07.pub guardia-tp-cible
# =============================================================================

set -euo pipefail

ADMIN_USER="ansible"
HARDENING_DROPIN="/etc/ssh/sshd_config.d/99-guardia-hardening.conf"
SUDOERS_DROPIN="/etc/sudoers.d/90-${ADMIN_USER}-nopasswd"

if [[ ${EUID} -ne 0 ]]; then
  echo "Erreur : ce script doit etre execute en tant que root (sudo)." >&2
  exit 1
fi

PUBKEY_FILE="${1:-}"
TARGET_HOSTNAME="${2:-guardia-tp-cible}"

if [[ -z "$PUBKEY_FILE" || ! -f "$PUBKEY_FILE" ]]; then
  echo "Usage : sudo $0 /chemin/vers/cle_publique.pub [hostname]" >&2
  echo "Erreur : fichier de cle publique SSH introuvable ou non fourni." >&2
  exit 1
fi

PUBKEY_CONTENT="$(cat "$PUBKEY_FILE")"
if [[ ! "$PUBKEY_CONTENT" =~ ^(ssh-ed25519|ssh-rsa|ecdsa-sha2-) ]]; then
  echo "Erreur : le contenu de ${PUBKEY_FILE} ne ressemble pas a une cle" >&2
  echo "         publique SSH valide (doit commencer par ssh-ed25519," >&2
  echo "         ssh-rsa ou ecdsa-sha2-...)." >&2
  exit 1
fi

echo "== 1/6 : mise a jour des paquets et installation des prerequis =="
apt-get update
apt-get install -y sudo openssh-server open-vm-tools

echo "== 2/6 : creation du compte admin '${ADMIN_USER}' =="
if id "$ADMIN_USER" >/dev/null 2>&1; then
  echo "   -> compte '${ADMIN_USER}' deja present, on continue."
else
  useradd -m -s /bin/bash -c "Compte admin Ansible (TP Guardia)" "$ADMIN_USER"
fi
# Verrouille le mot de passe : connexion possible uniquement par cle SSH.
passwd -l "$ADMIN_USER"

install -d -m 700 -o "$ADMIN_USER" -g "$ADMIN_USER" "/home/${ADMIN_USER}/.ssh"
printf '%s\n' "$PUBKEY_CONTENT" > "/home/${ADMIN_USER}/.ssh/authorized_keys"
chmod 600 "/home/${ADMIN_USER}/.ssh/authorized_keys"
chown "${ADMIN_USER}:${ADMIN_USER}" "/home/${ADMIN_USER}/.ssh/authorized_keys"

echo "== 3/6 : sudo NOPASSWD pour '${ADMIN_USER}' (compromis documente TP 4 jours) =="
usermod -aG sudo "$ADMIN_USER"
echo "${ADMIN_USER} ALL=(ALL) NOPASSWD:ALL" > "$SUDOERS_DROPIN"
chmod 440 "$SUDOERS_DROPIN"
visudo -c -f "$SUDOERS_DROPIN"

echo "== 4/6 : durcissement SSH (cle uniquement, pas de root) =="
# Suppose que /etc/ssh/sshd_config contient bien "Include sshd_config.d/*.conf"
# (present par defaut dans le paquet openssh-server de Debian 13).
cat > "$HARDENING_DROPIN" <<'EOF'
# Ajoute par post-install-fallback.sh (TP Guardia) : authentification par
# cle SSH uniquement, connexion root SSH desactivee.
PermitRootLogin no
PasswordAuthentication no
EOF
chmod 644 "$HARDENING_DROPIN"
sshd -t
systemctl restart ssh

echo "== 5/6 : activation d'open-vm-tools =="
systemctl enable --now open-vm-tools

echo "== 6/6 : hostname =="
hostnamectl set-hostname "$TARGET_HOSTNAME"
if ! grep -qE "127\.0\.1\.1[[:space:]]+${TARGET_HOSTNAME}" /etc/hosts; then
  echo "127.0.1.1   ${TARGET_HOSTNAME}" >> /etc/hosts
fi

echo
echo "== Termine =="
echo "Verifier depuis la machine hote : ssh ${ADMIN_USER}@<IP-de-la-VM>"
echo "(recuperer l'IP de la VM sur la VM elle-meme avec : hostname -I)"
echo
echo "Rappel : le compte de service applicatif 'tpapp' n'est PAS cree par ce"
echo "script. Il sera cree par le playbook Ansible (livrable 5) lors du"
echo "deploiement de l'application."
