#!/usr/bin/env bash
# =============================================================================
# build-seed-iso.sh
#
# Construit l'ISO "seed" NoCloud (cloud-init) a partir des fichiers
# 04-vm-template/cloud-init/{user-data,meta-data,network-config}.yaml
#
# A EXECUTER MANUELLEMENT PAR L'ETUDIANT, sur la machine HOTE (PAS dans la
# VM cible), avant de demarrer la VM cible avec cloud-init pour la premiere
# fois. Ce script ne modifie rien d'autre que le fichier ISO de sortie : il
# ne touche a aucune VM, aucune infrastructure distante.
#
# Prerequis (un seul des deux suffit) :
#   - cloud-image-utils (fournit la commande "cloud-localds")  -> RECOMMANDE
#   - genisoimage (solution de secours, utilise -graft-points)
#   Sous Debian/Ubuntu, a installer soi-meme au besoin :
#     sudo apt update && sudo apt install -y cloud-image-utils
#     ou
#     sudo apt update && sudo apt install -y genisoimage
#   Sous Windows : executer ce script depuis WSL2 (Debian ou Ubuntu), car
#   VMware Workstation Player ne fournit pas ces outils nativement et ce
#   script est un script bash.
#
# Usage :
#   ./build-seed-iso.sh [chemin/de/sortie/seed.iso]
#   Sans argument, l'ISO est creee a cote de ce script : ./seed.iso
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLOUD_INIT_DIR="${SCRIPT_DIR}/cloud-init"

USER_DATA="${CLOUD_INIT_DIR}/user-data.yaml"
META_DATA="${CLOUD_INIT_DIR}/meta-data.yaml"
NETWORK_CONFIG="${CLOUD_INIT_DIR}/network-config.yaml"

OUTPUT_ISO="${1:-${SCRIPT_DIR}/seed.iso}"

echo "== build-seed-iso.sh : construction de l'ISO seed NoCloud =="

for f in "$USER_DATA" "$META_DATA" "$NETWORK_CONFIG"; do
  if [[ ! -f "$f" ]]; then
    echo "Erreur : fichier introuvable : $f" >&2
    exit 1
  fi
done

# Garde-fou : empeche de construire une ISO avec la cle SSH placeholder non
# remplacee (voir instructions en tete de cloud-init/user-data.yaml).
if grep -q "REMPLACERPARVOTRECLEPUBLIQUE" "$USER_DATA"; then
  echo "Erreur : cloud-init/user-data.yaml contient encore la cle SSH" >&2
  echo "         placeholder. Generer sa propre paire de cles :" >&2
  echo "           ssh-keygen -t ed25519 -C \"etuNN@guardia-tp\"" >&2
  echo "         puis remplacer la ligne ssh_authorized_keys dans" >&2
  echo "         cloud-init/user-data.yaml avant de relancer ce script." >&2
  exit 1
fi

if [[ -e "$OUTPUT_ISO" ]]; then
  echo "Attention : ${OUTPUT_ISO} existe deja, il sera ecrase."
fi

if command -v cloud-localds >/dev/null 2>&1; then
  echo "-> Utilisation de cloud-localds"
  cloud-localds \
    --network-config="$NETWORK_CONFIG" \
    "$OUTPUT_ISO" \
    "$USER_DATA" \
    "$META_DATA"
elif command -v genisoimage >/dev/null 2>&1; then
  echo "-> Utilisation de genisoimage (cloud-localds absent)"
  genisoimage \
    -output "$OUTPUT_ISO" \
    -volid cidata \
    -joliet -rock \
    -graft-points \
    "user-data=${USER_DATA}" \
    "meta-data=${META_DATA}" \
    "network-config=${NETWORK_CONFIG}"
else
  echo "Erreur : ni cloud-localds ni genisoimage n'est installe sur cette" >&2
  echo "         machine. Installer l'un des deux paquets, par exemple :" >&2
  echo "           sudo apt update && sudo apt install -y cloud-image-utils" >&2
  echo "         ou" >&2
  echo "           sudo apt update && sudo apt install -y genisoimage" >&2
  exit 1
fi

echo
echo "== ISO seed generee : ${OUTPUT_ISO} =="
echo
echo "Etapes suivantes (a faire vous-meme, dans VMware Workstation Player) :"
echo "  1. VM cible eteinte : Player > Manage > Virtual Machine Settings"
echo "  2. Add... > CD/DVD Drive > terminer l'assistant (ajoute un 2e lecteur)"
echo "  3. Selectionner ce nouveau lecteur > 'Use ISO image file' > parcourir"
echo "     jusqu'a : ${OUTPUT_ISO}"
echo "  4. Cocher 'Connect at power on' puis valider (OK)"
echo "  5. Demarrer la VM : cloud-init doit detecter le datasource NoCloud"
echo "     (volume 'cidata') et appliquer la configuration au prochain boot,"
echo "     A CONDITION que le paquet cloud-init ait deja ete installe une"
echo "     premiere fois sur cette VM (voir 04-vm-template/README.md,"
echo "     'Chemin A', etape 0)."
echo
echo "NB : si VMware Workstation Player ignore ce second lecteur CD-ROM au"
echo "     demarrage (probleme frequent), ou si le reseau ne remonte pas,"
echo "     voir la section 'Points de blocage frequents' de"
echo "     04-vm-template/README.md."
