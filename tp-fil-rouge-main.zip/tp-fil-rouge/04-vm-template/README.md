# 04 - Template de VM cible etudiante (VMware Workstation Player)

Ce livrable prepare la VM locale de chaque etudiant (poste personnel, sous
VMware Workstation Player) qui servira de cible aux playbooks Ansible du
livrable 5. Il ne configure PAS l'application ni le pare-feu applicatif
(ufw, nginx, gunicorn) : cette partie est entierement geree par le playbook
Ansible (`05-ansible/site.yml`), qui s'execute apres cette etape.

Rappel important : rien dans ce dossier n'est execute automatiquement par
un assistant ou un script d'orchestration. Toutes les commandes montrees
ici (dans ce README ou dans les scripts) sont a executer VOUS-MEME, sur
VOTRE machine et VOTRE VM.

## Prerequis

- **Debian 13 ("Trixie")**, image d'installation officielle (netinst ou
  complete), telechargee depuis <https://www.debian.org/> par l'etudiant.
- **VMware Workstation Player 17.x ou plus recent**, sous Windows ou Linux
  (Workstation Player n'existe pas sous macOS ; pour un poste macOS, utiliser
  VMware Fusion avec les memes fichiers cloud-init, configuration non
  testee dans le cadre de ce TP).
- Sur la machine utilisee pour construire l'ISO seed
  (`build-seed-iso.sh`) : un shell bash et soit `cloud-image-utils`
  (recommande, fournit `cloud-localds`), soit `genisoimage`. Sous Windows,
  executer ce script depuis WSL2 (Debian/Ubuntu).
- **Chaque etudiant genere SA PROPRE paire de cles SSH** :
  ```
  ssh-keygen -t ed25519 -C "etuNN@guardia-tp"
  ```
  Il n'y a JAMAIS de cle partagee entre etudiants, ni de cle fournie par
  l'instructeur. La cle privee reste sur le poste de l'etudiant.

## Deux chemins possibles

Les deux chemins partent d'une installation Debian 13 **standard et
manuelle** depuis l'ISO officielle (partitionnement, mot de passe root ou
utilisateur local, selection de taches dans `tasksel` en cochant au moins
"serveur SSH" pour garder un acces de secours). La difference se joue
ensuite.

### Chemin A (recommande) : cloud-init (NoCloud, ISO seed)

Une ISO Debian d'installation standard ne contient PAS cloud-init
preinstalle : c'est un point important a comprendre avant de commencer.
Le chemin A se deroule donc en deux temps.

**Etape 0 (une seule fois, manuelle, avant tout le reste) :**
1. Installer Debian 13 normalement dans VMware Workstation Player.
2. Demarrer la VM une premiere fois, ouvrir une session (console VMware ou
   SSH avec le compte cree pendant l'installation).
3. Installer cloud-init :
   ```
   sudo apt update && sudo apt install -y cloud-init cloud-guest-utils
   ```
4. Eteindre la VM (`sudo poweroff`).

**Etape 1 : construire l'ISO seed (sur la machine HOTE, pas dans la VM) :**
1. Ouvrir `cloud-init/user-data.yaml` et remplacer la cle SSH placeholder
   par le contenu de VOTRE fichier `~/.ssh/id_ed25519.pub` (voir Prerequis).
2. Lancer :
   ```
   ./build-seed-iso.sh
   ```
   Le script refuse de continuer si la cle placeholder n'a pas ete
   remplacee. Il produit `seed.iso` a cote de lui.

**Etape 2 : attacher l'ISO et redemarrer :**
1. VM eteinte : Player > *Manage* > *Virtual Machine Settings*.
2. *Add...* > *CD/DVD Drive* > terminer l'assistant (ajoute un second
   lecteur, sans toucher au premier).
3. Selectionner ce nouveau lecteur > *Use ISO image file* > choisir
   `seed.iso`.
4. Cocher *Connect at power on*, valider.
5. Demarrer la VM. cloud-init detecte le datasource NoCloud (volume
   `cidata`) et applique `user-data.yaml` / `meta-data.yaml` /
   `network-config.yaml` : creation du compte `ansible` (cle SSH
   uniquement, sudo NOPASSWD), desactivation de l'authentification par
   mot de passe SSH et du login root, installation d'`open-vm-tools`,
   hostname `guardia-tp-cible`.
6. Verifier depuis la machine hote : `ssh ansible@<IP-de-la-VM>`.

Apres un premier passage reussi, vous pouvez deconnecter/retirer le
lecteur `seed.iso` (facultatif, cloud-init ne rejoue pas une instance deja
provisionnee, voir la note sur `instance-id` dans `meta-data.yaml`).

### Chemin B (secours) : script manuel `post-install-fallback.sh`

A utiliser si le chemin A echoue (VMware Player qui ignore le second
lecteur CD-ROM, cloud-init qui ne detecte pas le datasource, etc.).

1. Copier votre cle publique SSH (`~/.ssh/id_ed25519.pub`) sur la VM (cle
   USB, presse-papiers partage VMware Tools, ou re-saisie manuelle avec
   `nano`).
2. Copier `post-install-fallback.sh` sur la VM (memes moyens).
3. Sur la VM, en tant que root :
   ```
   sudo ./post-install-fallback.sh /chemin/vers/id_ed25519.pub guardia-tp-cible
   ```
4. Le script installe les paquets necessaires (`sudo`, `openssh-server`,
   `open-vm-tools`), cree le compte `ansible` (cle SSH uniquement, sudo
   NOPASSWD), durcit SSH (`PermitRootLogin no`, `PasswordAuthentication
   no`) et fixe le hostname.
5. Verifier depuis la machine hote : `ssh ansible@<IP-de-la-VM>`.

Dans les deux chemins, le resultat final est identique : un compte
`ansible` (sudo NOPASSWD, cle SSH uniquement), SSH durci, `open-vm-tools`
actif, hostname `guardia-tp-cible`.

## Ce qui n'est PAS fait ici

- Le compte de service applicatif **`tpapp`** n'est cree ni ici, ni dans
  cloud-init, ni dans le script de secours : il sera cree par le playbook
  Ansible du livrable 5 lors du deploiement de l'application.
- Le pare-feu applicatif (`ufw`, ports 22/80) n'est pas configure ici : il
  est gere par le playbook Ansible du livrable 5.
- Le port SSH de gestion reste le port par defaut **22** (non modifie), pour
  ne pas complexifier l'installation en debut de formation.

## Points de blocage frequents

- **VMware Workstation Player ignore le second lecteur CD-ROM au
  demarrage.** Frequent avec Player. Verifier dans *Virtual Machine
  Settings* que le lecteur pointe bien vers `seed.iso` et que *Connected*
  et *Connect at power on* sont bien coches. Un simple redemarrage du
  systeme d'exploitation invite (`reboot` dans la VM) ne suffit pas
  toujours : parfois il faut eteindre completement la VM (*Power Off*,
  pas *Restart*) puis la redemarrer pour que Player relise correctement
  l'etat du lecteur.
- **Reseau NAT vs Bridged.** Par defaut, VMware Workstation Player utilise
  le mode NAT : la VM recoit une IP privee via le commutateur virtuel
  `vmnet8`, generalement joignable depuis la machine hote elle-meme. Si le
  runner Gitea Actions (livrable 6) tourne dans Docker sur ce meme poste,
  le reseau virtuel Docker peut parfois ne pas router correctement vers le
  reseau virtuel VMware (conflit frequent entre les piles reseau Docker et
  VMware, notamment sous Windows). Tester tot la connectivite (`ping`,
  `ssh`) depuis un conteneur Docker jetable vers l'IP de la VM ; en cas
  d'echec, basculer la carte reseau de la VM en mode **Bridged** (la VM
  obtient alors une IP directement sur le reseau physique du poste, sous
  reserve que le reseau du campus Guardia autorise le DHCP pour des
  machines supplementaires, ce qui n'est pas garanti).
- **cloud-init absent d'une ISO Debian standard.** Rappel du Chemin A,
  etape 0 : une installation Debian classique ne contient pas cloud-init
  par defaut. Sans cette etape manuelle prealable, attacher `seed.iso` ne
  fait rien.
- **Nom d'interface reseau variable.** Selon le mode reseau et le pilote de
  carte emule par VMware, l'interface peut s'appeler `ens33`, `ens160`,
  etc. `network-config.yaml` matche par prefixe (`en*`) pour rester
  portable, mais en cas de souci, verifier le nom reel avec `ip a` sur la
  VM.
- **Cache d'instance cloud-init.** La VM etant recreee frequemment pendant
  le TP, si vous modifiez `user-data.yaml` et reconstruisez `seed.iso` sans
  changer `instance-id` dans `meta-data.yaml`, cloud-init ne rejoue rien au
  boot suivant. Executer `sudo cloud-init clean --logs` sur la VM avant de
  redemarrer avec la nouvelle ISO (detail deja documente dans
  `meta-data.yaml`).
- **Nom du service SSH.** Sous Debian, le service systemd s'appelle `ssh`
  (pas `sshd`) : `systemctl restart ssh`, `systemctl status ssh`.

## Compromis de securite assumes (documentes, propres a ce lab de 4 jours)

- Sudo `NOPASSWD:ALL` large sur le compte `ansible`, pour simplifier
  l'execution des playbooks Ansible pendant le TP. A ne jamais reproduire
  en environnement de production.
- Port SSH de gestion laisse a 22 (par defaut), non deplace.
