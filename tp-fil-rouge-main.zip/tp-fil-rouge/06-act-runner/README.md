# Livrable 6 : Runner Gitea Actions local (poste etudiant)

Ce repertoire fournit le Docker Compose du runner Gitea Actions (`act_runner`) qui tourne
en local, sur la VM cible de chaque etudiant (celle provisionnee au livrable 4, PAS la VM
`gitea-guardia` du livrable 1). Ce runner execute les jobs du workflow
`.gitea/workflows/deploy.yml` (livrable 7) : lint, test, deploy.

Toutes les commandes de ce document sont a executer manuellement par l'etudiant sur sa
propre VM cible. Aucune commande de ce fichier n'est executee par l'assistant ni sur une
infrastructure reelle.

## Prerequis (poste etudiant, VM cible Debian 13)

- Docker Engine version 25.0 ou superieure.
- Plugin Docker Compose v2 integre, `docker compose version` doit afficher v2.24 ou superieur.
- Noyau Linux avec cgroup v2 actif (par defaut sur Debian 13).
- Acces reseau sortant vers `https://gitea-guardia.novidemo.fr` (HTTPS, port 443) depuis la
  VM cible, pour l'enregistrement et le polling du runner.

Verifier les versions installees (a executer par l'etudiant) :

```
docker --version
docker compose version
```

## Etapes de lancement (a executer par l'etudiant, dans ce repertoire)

1. Recuperer le token d'enregistrement de runner aupres de l'instructeur (fourni par
   organisation etudiante via le script d'enrolement du livrable 3), ou le regenerer
   soi-meme depuis l'interface web Gitea : organisation `guardia-etuNN` > Settings >
   Actions > Runners > "Create new runner".

2. Copier le fichier d'environnement et le completer :

   ```
   cp .env.example .env
   ```

   Puis editer `.env` et renseigner `GITEA_RUNNER_REGISTRATION_TOKEN` (et adapter
   `GITEA_RUNNER_NAME` avec son identifiant `etuNN`). Ne jamais commiter ce fichier `.env`
   dans le depot Git de l'etudiant (seul `.env.example` doit s'y trouver).

3. Demarrer la pile :

   ```
   docker compose up -d
   ```

4. Verifier que les deux services sont sains :

   ```
   docker compose ps
   docker compose logs -f runner
   ```

   Le journal du service `runner` doit indiquer un enregistrement reussi aupres de
   l'instance Gitea (message de type "runner registered" ou similaire), sans erreur de
   connexion au sidecar `dind`.

## Verification cote Gitea (interface web)

Se connecter a `https://gitea-guardia.novidemo.fr` avec son compte `etuNN`, puis :

- Aller dans l'organisation concernee : `guardia-etuNN` > Settings > Actions > Runners.
- Le runner doit apparaitre dans la liste avec le statut "Idle" (ou "Active" pendant
  l'execution d'un job), portant le nom renseigne dans `GITEA_RUNNER_NAME` et le label
  configure dans `GITEA_RUNNER_LABELS`.
- Ce runner n'est visible et utilisable que dans l'organisation de l'etudiant qui l'a
  enregistre : le token d'enregistrement recupere au niveau de l'organisation garantit
  cette isolation entre etudiants (voir livrable 3).

## Pourquoi le sidecar dind tourne en privileged:true

Chaque step d'un job Gitea Actions (executor `docker`) tourne dans un conteneur ephemere
cree a la volee par le sidecar `dind`. Pour heberger ce Docker-in-Docker, deux variantes
existent : classique (`privileged: true`) ou rootless.

**La variante rootless a ete testee et abandonnee le 17/09/2026**, apres qu'elle a bloque
plusieurs etudiants en plein TP : son daemon Docker interne, prive de systemd (donc de
veritable delegation cgroup v2), tourne en `Cgroup Driver: none` et ne peut alors creer
AUCUN conteneur de job, meme le plus basique (erreur `operation not permitted` a la
creation, avant meme d'atteindre la premiere etape du job). Verifie par un test de
controle strict, sur la meme machine, avec les deux variantes : le dind classique cree un
conteneur de job sans probleme, le dind rootless echoue systematiquement. Tenter d'ajouter
un mode privilegie uniquement au niveau des conteneurs de job (`container.privileged`
dans la configuration `act_runner`) ou de forcer `cgroup: host` sur le sidecar rootless
n'a change aucun des deux resultats.

Le sidecar `dind` tourne donc desormais en **variante classique privilegiee** (image
officielle `docker:27-dind`, `privileged: true`) :

- Cette elevation de privileges reste circonscrite au seul conteneur `dind` : le service
  `runner` (act_runner) n'a lui-meme jamais `privileged: true` et n'a aucun acces au
  socket Docker de l'hote (`/var/run/docker.sock`) ; il ne parle qu'au sidecar `dind` via
  le reseau interne du compose.
- En cas d'evasion de conteneur depuis `dind`, c'est le noyau de la VM cible de
  l'etudiant qui serait expose, jamais le poste physique Guardia ni le homelab Novicore.
  Cette VM cible est jetable et recreee a chaque TP (cf. livrable 4), ce qui borne le
  risque pour un TP pedagogique de 4 jours.
- Aucun port n'est publie vers l'hote pour `dind`, et aucun montage du socket Docker de
  l'hote n'existe nulle part dans ce compose.

## Alternative de secours (fallback, PAS la solution par defaut)

Si le sidecar `dind` ne demarre pas correctement sur un poste Guardia particulier
(incompatibilite noyau, restriction locale sur `privileged: true`), la solution de repli
documentee ici, a n'utiliser qu'en dernier recours pour l'etudiant concerne, est la
suivante :

- Remplacer l'executor `docker` de `act_runner` par l'executor natif **`host`**
  (parametre `CONFIG_FILE` / section `runner.container` de la configuration `act_runner`,
  a adapter en dehors de ce compose) : dans ce mode, chaque step de job s'execute
  directement dans l'environnement du conteneur `runner` lui-meme, sans creer de
  sous-conteneurs Docker, donc sans besoin de sidecar `dind` ni de capabilities
  additionnelles.
- Ce mode de secours a un cout de securite et de reproductibilite plus eleve : les steps
  du workflow ne sont plus isoles dans un conteneur ephemere propre a chaque job, ils
  s'executent dans l'environnement partage et persistant du conteneur `runner`, avec un
  risque de pollution/contamination entre executions successives.
- Ce fallback doit rester exceptionnel et documente au cas par cas (poste concerne,
  raison du blocage), il ne doit pas devenir la configuration par defaut de la classe :
  en cas de blocage generalise sur plusieurs postes, remonter le probleme a l'instructeur
  avant de generaliser ce contournement.
